package com.pageObjectRepo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class LoginRepo {
	
	@FindBy(xpath  = "//input[@data-placeholder='Email']")
	@CacheLookup// this is use for webElement never change 
	private WebElement txtEmail;

	@FindBy(xpath  = "//input[@data-placeholder='Password']")
	@CacheLookup
	private WebElement txtPassword;
	
	@FindBy(xpath  = "//span[text()='Login']")
	public WebElement btnLogin;
	
	@FindBy(xpath  = "//a[text()='Logout']")
	public WebElement btnLogout;

	public WebElement getTxtEmail() {
		return txtEmail;
	}

	public void setTxtEmail(WebElement txtEmail) {
		this.txtEmail = txtEmail;
	}

	public WebElement getTxtPassword() {
		return txtPassword;
	}

	public void setTxtPassword(WebElement txtPassword) {
		this.txtPassword = txtPassword;
	}


}
