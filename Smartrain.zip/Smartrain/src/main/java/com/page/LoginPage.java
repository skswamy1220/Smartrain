package com.page;


import org.openqa.selenium.support.PageFactory;
import com.base.BaseClass;
import com.pageObjectRepo.LoginRepo;
import com.utility.CustomizeMethod;


public class LoginPage extends LoginRepo {
	
	public LoginPage()
	{
		PageFactory.initElements(BaseClass.webDriver.get(), this);
	}
	CustomizeMethod method= new CustomizeMethod(BaseClass.webDriver.get());
	public void setUserName(String uname)
	{
		 setTxtEmail(getTxtEmail());//storing webElement
		 method.sendKeys(getTxtEmail(), uname);
	}
	public void setUserPassword(String pass)
	{
		setTxtPassword(getTxtPassword());
		method.sendKeys(getTxtPassword(), pass);
	}
	public void clickLogin()
	{
		method.click(btnLogin, BaseClass.webDriver.get());
	}
	public void clickLogout()
	{
		method.click(btnLogout, BaseClass.webDriver.get());
	}

}
